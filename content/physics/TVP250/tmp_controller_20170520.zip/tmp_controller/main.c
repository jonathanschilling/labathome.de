#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdlib.h>
#include <stdio.h>

#include "lcd_routines.h"
#include "adc.h"

#define STATE_IDLE 4

volatile uint8_t current_in;
volatile uint8_t last_in;
volatile uint8_t current_state;
volatile uint16_t timer_val;
volatile uint32_t lcd_update;

// variables used as booleans
uint8_t accelerate;
uint8_t next_state;
uint8_t idle;
uint8_t hold;
uint8_t updated;

// rotor frequency
int freq;

// ADC input values
uint16_t adc0, adc1, adc4, adc5;

char Buffer[20]; // buffer for conversion of numbers to strings

// determine rotor position based on ADC values
// derivation of values involved some paperwork...
uint8_t get_position(uint16_t adc0, uint16_t adc1) {
	if        (373 <= adc0 && adc0 < 457 && 373 <= adc1              ) {
		return 0;
	} else if (373 <= adc0               && 343 <= adc1 && adc1 < 374) {
		return 10;
	} else if (447 <= adc0               && 298 <= adc1 && adc1 < 343) {
		return 15;
	} else if (384 <= adc0               && 223 <= adc1 && adc1 < 298) {
		return 20;
	} else if (384 <= adc0               && 136 <= adc1 && adc1 < 223) {
		return 30;
	} else if (338 <= adc0 && adc0 < 384                && adc1 < 223) {
		return 40;
	} else if (304 <= adc0 && adc0 < 338                && adc1 < 152) {
		return 45;
	} else if (225 <= adc0 && adc0 < 304                && adc1 < 214) {
		return 50;
	} else if (               adc0 < 225                && adc1 < 214) {
		return 60;
	} else if (               adc0 < 225 && 214 <= adc1 && adc1 < 256) {
		return 70;
	} else if (               adc0 < 225 && 256 <= adc1 && adc1 < 288) {
		return 75;
	} else if (               adc0 < 219 && 288 <= adc1 && adc1 < 361) {
		return 80;
	} else if (134 <= adc0 && adc0 < 219 && 361 <= adc1 && adc1 < 440) {
		return 90;
	} else if (219 <= adc0 && adc0 < 246 && 361 <= adc1              ) {
		return 100;
	} else if (246 <= adc0 && adc0 < 296 && 431 <= adc1              ) {
		return 105;
	} else if (296 <= adc0 && adc0 < 373 && 374 <= adc1              ) {
		return 110;
	} else {
		return 255;
	}
}

// state refers to the current rotor position
// By executing consecutive states, the rotor is rotated.
uint8_t execute_state(uint8_t state) {
  uint8_t return_state=0;
  if (state==0) {
	PORTB |= (1<<PB0);
	PORTD &= ~(1<<PD6);
	PORTB |= (1<<PB2);
	PORTB &= ~(1<<PB1);

	return_state=0;
  }
  else if (state==1) {
	PORTB &= ~(1<<PB2);	
	PORTD |= (1<<PD7);
	PORTB &= ~(1<<PB4);
	PORTB |= (1<<PB1);

	return_state=1;
  }
  else if (state==2) {
	PORTB &= ~(1<<PB0);
	PORTD |= (1<<PD6);
	PORTB |= (1<<PB2);
	PORTB &= ~(1<<PB1);

	return_state=2;
  }
  else if (state==3) {
	PORTB &= ~(1<<PB2);	
	PORTD &= ~(1<<PD7);
	PORTB |= (1<<PB4);
	PORTB |= (1<<PB1);

	return_state=3;
  } else if (state==STATE_IDLE) {
  	PORTB &= ~(1<<PB0);
	PORTB &= ~(1<<PB1);
	PORTB &= ~(1<<PB2);
	PORTB &= ~(1<<PB4);
	PORTD &= ~(1<<PD6);
	PORTD &= ~(1<<PD7);

	return_state=STATE_IDLE;
  }


  return return_state;
}

int main(void) {

	// initial value for rotor position: 0
	current_state=0;

	// current rotor position
	current_in=0;

	// last input default value: something else than current_in
	last_in=255;
	
	// determine if the LCD needs an update
	lcd_update=0;
	
	// start in idle mode
	idle=1;

	// do not hold current frequency
	hold=0;

	// start in forward acceleration mode
	accelerate=1;

	// current timer value not updated yet.
	updated=0;

	// rotor frequency
	freq=0.0;
	
	// set outputs for driver outputs and debug output (PB5)
	DDRB |= (1<<PB0) | (1<<PB1) | (1<<PB2) | (1<<PB4);
	DDRD |= (1<<PD6) | (1<<PD7);
	DDRB |= (1<<PB5);

   
	// TIM1 as counter for determining current frequency
	// prescaler 256 --> 31250 Hz
	TCCR1B |= (1<<CS12);
	
	// initialize LCD
	lcd_init();

	// print welcome message
	lcd_setcursor(0,1);
	lcd_string("press start");
	
	// init ADC
	ADC_Init();
   

    while( 1 ) {

		// averaging really makes the frequency calculation work !!!
		// todo: interleaved sampling and averaging for phase coherency
		// ch0 and 1: Hall sensors
		adc0 = ADC_Read_Avg(0, 4);  // channel 0
		adc1 = ADC_Read_Avg(1, 4);  // channel 1
		
		// pushbuttons
		adc4 = ADC_Read(4);
		adc5 = ADC_Read(5);

		// get left button
		if (adc4 < 512) {
			idle=0;
			accelerate = 1;
		}

		// get right button
		if (adc5 < 512) {
			accelerate = 0;
		}

		// get current rotor position from ADC values
		current_in=get_position(adc0, adc1);
		
		// decide wether to go to next phase...
		if (current_in != last_in || idle || (!idle && accelerate)) {
			
			if (!idle) {
				// execute appropriate motor coil state
				if        (current_in <= 15 || current_in > 105) { // 0
					if (accelerate) {
						next_state=1;
					} else {
						next_state=3;
					}
				} else if (current_in <= 45 && current_in > 15) { // 1
					if (accelerate) {
						next_state=2;
					} else {
						next_state=0;
					}
				} else if (current_in <= 75 && current_in > 45) { // 2
					if (accelerate) {
						next_state=3;
					} else {
						next_state=1;
					}
				} else { // <= 105 || > 75 => 3
					if (accelerate) {
						next_state=0;
					} else {
						next_state=2;
					}
				}

				current_state=execute_state(next_state);
			} else {
				// disable driver in idle state
				execute_state(STATE_IDLE);
			}

			// once per rotation, update timer
			if (!updated && current_in == 0) {

				// set debug output: ch2 on oscilloscope to determine computation time
				PORTB |= (1<<PB5);

				// save timer value
				timer_val=TCNT1;

				// add current timer val to LCD
				lcd_update += timer_val;
			
				// if lcd_update accumulated enough time, update LCD
				if (lcd_update > (1l<<11)) {
					
					// calc rotor frequency from last timer reading
					// 8MHz/256 (prescaler) = 31250 Hz
					freq=(int)round(31250.0/((double)timer_val));

					// determine wether to switch into idle mode after deceleration ...
					if (freq < 5 && !accelerate) {
						idle=1;
					} else if (freq > 500) {
						// ... or stay at current frequency in hold mode (not implemented yet)
						hold=1;
					}
					
					// print info to LCD
					if (!idle) {
						lcd_setcursor(0,1);
						if (accelerate) {
							lcd_string("accelerate ");
						} else {
							lcd_string("decelerate ");
						}
						
						lcd_setcursor(10,2);
						sprintf(Buffer, "%3d Hz", freq);
						lcd_string(Buffer);
					} else if (freq < 5) {
						lcd_setcursor(0,1);
						lcd_string("           ");
						
						lcd_setcursor(10,2);
						lcd_string("idle  ");
					}
					
					// update of LCD is done
					lcd_update=0;
				}
				// reset timer
				TCNT1=0;

				// update of timer value is done
				updated = 1;
			
				// disable debug output
				PORTB &= ~(1<<PB5);		
			
			} else if (current_in > 0) {
				// any other rotor position: need for updating timer value
				updated = 0;
			}
			
			// wait until rotor position changes
			last_in=current_in;
		}
    }

	// should never reach this...
	return 0;
}


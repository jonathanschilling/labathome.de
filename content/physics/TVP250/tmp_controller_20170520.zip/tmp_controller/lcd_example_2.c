// 
// Anpassungen im makefile:
//    ATMega8 => MCU=atmega8 im makefile einstellen
//    lcd-routines.c in SRC = ... Zeile anhängen 
// 
#include <avr/io.h>
#include <stdlib.h>
#include "lcd-routines.h"

// Beispiel
int variable = 42;

int main(void)
{
  lcd_init();

  // Ausgabe des Zeichens dessen ASCII-Code gleich dem Variablenwert ist
  // (Im Beispiel entspricht der ASCII-Code 42 dem Zeichen *)
  // http://www.code-knacker.de/ascii.htm
  lcd_data( variable );

  lcd_setcursor( 0, 2 );
 
  // Ausgabe der Variable als Text in dezimaler Schreibweise
  {
     // ... umwandeln siehe FAQ Artikel bei http://www.mikrocontroller.net/articles/FAQ
     // WinAVR hat eine itoa()-Funktion, das erfordert obiges #include <stdlib.h>
     char Buffer[20]; // in diesem {} lokal
     itoa( variable, Buffer, 10 ); 

     // ... ausgeben  
     lcd_string( Buffer );
  }

  while(1)
  {
  }

  return 0;
}

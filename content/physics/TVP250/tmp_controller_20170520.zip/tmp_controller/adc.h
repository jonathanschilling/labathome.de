#ifndef ADC_H
#define ADC_H

#include <avr/io.h>

/* ADC initialisieren */
void ADC_Init(void);

/* ADC Einzelmessung */
uint16_t ADC_Read( uint8_t channel );

/* ADC Mehrfachmessung mit Mittelwertbbildung */
/* beachte: Wertebereich der Summenvariablen */
uint16_t ADC_Read_Avg( uint8_t channel, uint32_t nsamples );

#endif //ADC_H
